<!-- classes são modelos para criar objetos -->
<!-- método = ação(função) -->
<!-- em php mais avançado existe sim o tipo da variavel, opcional -->
<!-- A herança permite que a gente reaproveite códigos, uma classe herda proprietades e metodos de outra classe -->
<?php
class Animal{
    public int $peso; 
    public int $altura;
    protected string $quimicaDoSangue;

    protected function produzirInsulina(){
        return "Insulina";
    }

    public function locomover(){
        echo "Pela estrada a fora eu vou bem ...";
    }

    public function comer(){
        echo "Pope Franciss";
    }
}

// quando uma classe extende a outra quer dizer que a classe herda tudo o que é publico protegido da outra classe. Métodos e propriedades privados não podem ser herdados//
class Cachorro extends Animal 
{
    public function locomover(){
        echo "au, au....quem ta lendo é animal";
    }
}

class Humano extends Animal {

    public function comer(){
        echo "comer comeeer comer comeeer...é o melhor para poder crescer";
    }

    public function falar(string $palavras){
        echo $palavras;
    }
}

$cobra = new Animal();
$cobra ->altura = 30;
$cobra ->peso = 100;
$cobra ->locomover();
$cobra ->comer();

$thor = new Cachorro();
$thor ->locomover();
$thor ->comer();

$juliana = new Humano();
$juliana ->falar("Awwwwww que cacholo bonitinho!!!!!!!");
$juliana ->locomover();

// Uma interface é um padrão que define quais métodos uma classe deve implementar. Uma interface não pode ter métodos implementados e não pode ter propriedades. Uma interface não pode ser instanciada

    interface IAutentica
    {
        public function autenticar(String $senha): bool;
        public function desautenticar(): void;
        public function estaAutenticado(): bool;
    }

    function autentica(IAutentica $moduloDeAutenicacao, string $senha)
    {
        if ($moduloDeAutenicacao -> estaAutenticado()){
            return;
        }
        if ($moduloDeAutenicacao -> autenticar($senha)){
            echo "Usuario autenticado com sucesso";
        }else {
            echo "Senha inválida";
        }
    }

    class AutenticacaoComAuAu implements IAutentica {

        private bool $autenticado = false;

        public function autenticar(string $senha): bool
        {
            if($senha === "auau"){
                $this -> autenticado = true;
            }else{

            $this->autenticado = false;
        }
            return $this -> autenticado;
        }
        public function desautenticar(): void
        {
            $this->autenticado = false;
            echo "Desautenticado com sucesso!";
        }
        public function estaAutenticado(): bool
        {
            return $this -> autenticado;
        }
    }

    $autenticador = new AutenticacaoComAuAu();

    autentica($autenticador, "uga");
    autentica($autenticador, "auau");
