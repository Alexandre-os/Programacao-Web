<?php
    // sempre usar $ pra declarar variavel

    //variavel de texto
    $mensagem = "ola mundo";

    //variavel numérica
    $idade = 15;

    //array vazio
    $lista = array();
    //adiciona valores no array
    $lista[]="Teste1";
    $lista[]="Teste2";
    $lista[]="Teste3";

    //array não vazio
    $lista2 = array("Teste1", "Teste 2", "Teste3");
    $lista2[] = "Teste4";
    $lista2[] = "Teste5";

    //arrays numéricos
    $lista3 = array();
    $lista3 =1;
    $lista3 =4;
    $lista3 =5;
    $lista3 =6;
    $lista3 =90;
    $lista3 =0.4;
// Acessando Valores
    echo $lista3[0];

    // Arrays com chave
    $lista4 = array();
    $lista4["RG"] = 4246548585;
    $lista4["cpf"] = 2544689578;
    $lista4["nome"] = "Uga";
    $lista4[] = "Caverna";
// Acessando Valores
    echo $lista4["RG"];
    echo $lista4["cpf"];

    // Arrays com chave numérica
    $lista5 = array();
    $lista5[2] = "Uga";
    $lista5[0] = 10;
    $lista5[20] = 45.6;

    //array não vazio
    $lista6 = array("RG" => 66464664, "CPF" => 45685285245, "nome" => "uga", "caverna");

    for ($i = 0; $i < count ($lista); $i++) {
        echo $lista[$i];
    }
    foreach ($lista6 as $chave => $valor) {
        echo $chave;
        echo $valor;
    }








?>