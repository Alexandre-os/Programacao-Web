<?php

namespace Etec\Luidgi\Controller;


class Principal {

    /**
     * a classe enviroment serve como gerenciadora dos dados
     *  que vem do template e do controlador, o papel dela é 
     * combinar os dados e gerar o html final
     * @var\Twig\Environment
     */

    private \Twig\Environment $ambiente;
    /**
     * O carregador tem a função de ler o template
     * de alguma origem. Neste caso carregaremos o 
     * template do sistema de arquivos(ou seja,
     * disco ou armazenamento local)
     * @var \Twig\Loader\FilesystemLoader
     */
    private \Twig\Loader\FilesystemLoader $carregador;

    public function __constructor()
    {
        // Abre o diretorio onde se encontram os templates
        $this->carregador = new \Twig\Loader\FilesystemLoader("./src/View");

        // Combina os dados com o template
        $this->ambiente = new \Twig\Environment($this->carregador);
    }

    public function início(array $dados)
    {

        $dados["titulo"]="Pagina inicial";
        $dados["mensagem"]="Uga";
        // Exibe a pagina construida
        echo $this->ambiente->render("inicio.html", $dados);
    }
}

