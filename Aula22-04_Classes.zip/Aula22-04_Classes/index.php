<?php
require_once 'vendor/autoload.php';

const URL = "http://localhost";

// Criar o roteador
$roteador = new CoffeeCode\Router\Router(URL);

// Informa o diretório onde os controladores se encontram
$roteador->namespace("Etec\Luidgi\Controller"); 

// Rota principal
$roteador->group(null);
$roteador->get("/", "Principal:início");

$roteador->dispatch();