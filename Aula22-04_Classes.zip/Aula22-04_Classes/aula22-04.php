<?php

class Animal {
    // Propriedades = Variáveis
    public int $peso;
    public int $altura;

    // O protected é um private só que pode ser herdado
    protected string $quimicaDoSangue;

    private function produzirInsulina() {
        return "insulina";
    }

    // Métodos = funções e procedimentos
    public function locomover() {
        echo "Estou indo embora, bora";
    }

    public function comer() {
        echo "nhac, nhac";
    }

}

// Herança: Quando uma classe extende a outra, isso significa que a classe herda tudo o que é público e protegido da outra classe.
// Métodos e propriedades privados NÃO PODEM ser herdados.
class Cachorro extends Animal {

    // sobreescrever um método, "modifica-lo para um comportamento diferente"
    public function locomover(){
        echo "au au, piff piff";
    }
}

class Humano extends Animal {

    public function comer(){
        echo "Comer comer, é o melhor para poder crescer";
    }

    public function falar(String $palavras){
        echo $palavras;
    }
}

$cobra = new Animal();
$cobra->altura = 30;
$cobra->peso = 100;
$cobra->locomover();
$cobra->comer();

$thor = new Cachorro();
$thor->locomover();
$thor->comer();

$juliana = new Humano();
$juliana->falar("OWNNNNN QUE FOFINHO");
$juliana->locomover();


// Uma interface é um padrão que define quais métodos uma classe deve implementar.
// Uma interface não pode ter métodos implementados e não pode ter propriedades.
// Uma interface não pode ser instaciada!
interface IAutentica{
    public function autenticar(string $senha): bool; // bool = retornar valor de Verdadeiro ou Falso

    public function desautenticar(): void;

    public function estaAutenticado(): bool;
}

function autentica(IAuntentica $moduloDeAutenticacao, string $senha){
    if ($moduloDeAutenticacao->estaAutenticado()){
        return;
    }

    if ($moduloDeAutenticacao->autenticar($senha)){
        echo "Usuário autenticado com sucesso!";
    } else {
        echo "Senha inválida!";
    }
}

class AutenticacaoComAuAu implements IAutentica {

    private bool $autenticado = false;

    public function autenticar(string $senha): bool {
        if ($senha === "auau"){
            $this->autenticado = true;
        } else {
                $this->autenticado = false;
        }
        return $this->autenticado;
    }

    public function desautenticar(): void {
        $this->autenticado = false;
        echo "Desautenticado com sucesso";
    }

    public function estaAutenticado(): bool {
        return $this->autenticado;
    }
}

$autenticador = new AutenticacaoComAuAu();

autentica($autenticador, "uga");
autentica($autenticador, "auau");



class AutenticaHumano implements Iautentica {
    private bool $autenticacao = false;

    public function autenticar(string $senha){
        if($senha === "olá mundo"){
            $this->autenticacao = true;
        } else {
            $this->autenticacao = false;
        }

        return $this->autenticacao;
    }

    public function desautenticar(): void {
        $this->autenticacao = false;
        echo "Usuário Desautenticado!";
    }

    public function estaAutenticado(): bool {
        return $this->autenticacao;
    }
}

$autenticadorHumano = new AutenticaHumano();

autentica($autenticadorHumano, "uga buga");
autentica($autenticadorHumano, "olá mundo");
?>