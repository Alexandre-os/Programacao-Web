<?php

interface Autentic
{
    public function autenticar(String $senha): bool;
    public function desautenticar(): void;
    public function Autenticado(): bool;
}

function autentica(Autentic $modulo, string $senha)
{
    if ($modulo -> Autenticado()){
        return;
    }
    if ($modulo -> autenticar($senha)){
        echo "foi";
    }else {
        echo "errou tenta outra";
    }
}

class Autenticacaocomsenha implements Autentic {

    private bool $autenticado = false;

    public function autenticar(string $senha): bool
    {
        if($senha === "auau"){
            $this -> autenticado = true;
        }else{

        $this->autenticado = false;
    }
        return $this -> autenticado;
    }
    public function desautenticar(): void
    {
        $this->autenticado = false;
        echo "Desautenticado com sucesso!";
    }
    public function Autenticado(): bool
    {
        return $this -> autenticado;
    }
}

$verificador = new Autenticacaocomsenha();

autentica($verificador, "uga");
autentica($verificador, "auau");
