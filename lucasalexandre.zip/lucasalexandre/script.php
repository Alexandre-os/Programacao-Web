<?php
header("Content-Type: application/json"); 

$certos = [
    "ola" => "mundo"
];

$json = file_get_contents('php://input');
$data = json_decode($json, true);

$login = $data["login"] ?? ""; 
$senha = $data["senha"] ?? "";

if (isset($certos[$login]) && $certos[$login] === $senha) {
    echo json_encode(["status" => "success"]);
} else {
    echo json_encode(["status" => "error"]);
} 
?>
